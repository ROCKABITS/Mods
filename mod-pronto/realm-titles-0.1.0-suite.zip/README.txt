Realm Titles and Realm Identity update

Minecraft 1.21.1 / NeoForge 21.1.256+ / Java 21

Install Realm Titles on the server and all clients. Realm Identity is optional;
if used, replace its older JAR with the included 0.1.1 on server and all clients.
Do not keep two versions of either mod. Titles has no required companion mods.

With Realm Council, the current sworn governor manages honours at the crafted
Royal Seal Desk. Without Council, an operator can appoint a steward using
/titles steward <onlinePlayer>. /titles desk gives the physical block to an OP.
All players may inspect the public registry by interacting with the desk.

Realm Identity displays current public titles when a valid document is inspected;
existing documents need not be reissued. Chronicles public names and Realm
Notifications are optional integrations. No title changes money or combat stats.

The seven existing roleplay mods and Origins/Jupiter were used for integration
validation and are not included. SHA256SUMS.txt verifies both production JARs.
