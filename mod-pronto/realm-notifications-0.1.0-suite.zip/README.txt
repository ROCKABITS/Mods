Realm Notifications and companion updates

Minecraft 1.21.1 / NeoForge 21.1.256+ / Java 21

Install Realm Notifications on the server and on each client that wants the HUD.
Companion mods are optional. Update only the companion mods you already use,
removing their older JARs first. All seven included JARs were built from the same
source commit and passed unit tests and their native Minecraft server suites.

Chronicles RP still requires the actual Origins (NeoForge) and Jupiter mods.
These third-party dependencies are not included. Realm Identity is unchanged
and is not included. Back up your world before replacing server mods.

Notification settings are client preferences. Notifications do not create or
move money; the companion mods remain responsible for transactions.

SHA256SUMS.txt verifies the seven unchanged production JARs in this archive.
